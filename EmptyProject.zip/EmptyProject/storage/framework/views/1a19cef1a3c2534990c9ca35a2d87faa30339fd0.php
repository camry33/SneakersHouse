<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <div class="background-image">
        <img src="b.jpg" width="100%" height="95%">
    </div>
</head>
<body>
<header id="header">
    <div class="header-middle">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="logo pull-left">
                        <a href="<?php echo e(url('/home')); ?>"><img src="logo.png" alt="" /></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="shop-menu pull-right">
                        <ul class="nav navbar-nav collapse navbar-collapse">
                            <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                            <li id="dropdown2"><a href="<?php echo e(url('#')); ?>">S h o e s&nbsp;&nbsp;G a l l e r y</a>
                                <div id="dropdowncontent2">
                                    <a href="<?php echo e(url('/sneakersgalery')); ?>">Nike</a>
                                    <a href="<?php echo e(url('/bootsgalery')); ?>">Adidas</a>
                                </div>
                            </li>
                            <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
                            <li><a href="login.html">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

    <br><br>
    <div class="member-section">
        <!--Not a member?
        <a href="Registration.html">create account</a>
        to access Market !<br>
        already member?
        <a href="#">Login!</a>-->
    </div>

    <div class="all-dem-shoes">
        <br>
        <div id="brand"><img src="/shoes gallery/brand2.png"> Nike</div><br><hr>
        <!-- <?php foreach($sneakerss->all() as $sneakers): ?>
            <img src="<?php echo e(asset($sneakers->picture)); ?>" alt="">
            <?php endforeach; ?>

        `   klo butuh databasenya ini
            !-->

        <div id="shoes">
            <?php foreach($adidas as $a): ?>
            <img src="/shoes gallery/<?php echo e($a->img); ?>">
            <?php endforeach; ?>
            <br>
            More Nike Shoes? <a href="#">Click Here</a>
        </div>
        <br><br>
        <div id="brand"><img src="/shoes gallery/brand1.png"> Adidas</div><br><hr>
        <div id="shoes">
            <img src="/shoes gallery/s7.png">
            <img src="/shoes gallery/s8.png">
            <img src="/shoes gallery/s9.png">
            <img src="/shoes gallery/s12.png"><br>
            More Adidas Shoes? <a href="#">Click Here</a>
        </div>
    </div>

    <div class="footer">
        Copyright Reserve (c)2017 , IT Team <br>
        Binus University
    </div>
</div>
</body>
</html>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>