        <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<header id="header">
    <div class="header-middle">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="logo pull-left">
                        <a href="<?php echo e(url('/home')); ?>"><img src="logo.png" alt="" /></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="shop-menu pull-right">
                        <ul class="nav navbar-nav collapse navbar-collapse">
                            <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                            <li id="dropdown2"><a href="<?php echo e(url('#')); ?>">S h o e s&nbsp;&nbsp;G a l l e r y</a>
                                <div id="dropdowncontent2">
                                    <a href="<?php echo e(url('/sneakersgalery')); ?>">Sneakers</a>
                                    <a href="<?php echo e(url('/bootsgalery')); ?>">Boots</a>
                                    <a href="<?php echo e(url('/pantofelgalery')); ?>">Pantofel</a>
                                </div>
                            </li>
                            <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
                            <li><a href="login.html">Login</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

    <br><br>
    <div class="member-section">
        <!--Not a member?
        <a href="Registration.html">create account</a>
        to access Market !<br>
        already member?
        <a href="#">Login!</a>-->
    </div>

    <div class="all-dem-shoes">
        <div id="brand"><img src="/shoes gallery/pbrand1.png"> Crocodiles</div><br><hr>
        <div id="shoes">
            <img src="/shoes gallery/p1.jpg">
            <img src="/shoes gallery/p2.jpg">
            <img src="/shoes gallery/p3.jpg">
            <img src="/shoes gallery/p4.jpg">
            <img src="/shoes gallery/p5.jpg"><br>
            More Crocodiles Shoes? <a href="#">Click Here</a>
        </div>
        <br><br>
        <div id="brand"><img src="/shoes gallery/pbrand2.png"> Bata</div><br><hr>
        <div id="shoes">
            <img src="/shoes gallery/p6.jpg">
            <img src="/shoes gallery/p7.jpg">
            <img src="/shoes gallery/p8.jpg">
            <img src="/shoes gallery/p9.jpg">
            <img src="/shoes gallery/p10.png"><br>
            More Bata Shoes? <a href="#">Click Here</a>
        </div>
    </div>

    <div class="footer1">
        Copyright Reserve (c)2017 , IT Team <br>
        Binus University
    </div>
</div>
</body>
</html>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>