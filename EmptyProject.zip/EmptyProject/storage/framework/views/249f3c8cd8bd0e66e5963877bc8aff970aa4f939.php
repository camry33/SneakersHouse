<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <div class="background-image">
        <img src="<?php echo e(asset('b.jpg')); ?>" width="100%" height="1190px">
    </div>
</head>

<header id="header">
    <div class="header-middle">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="logo pull-left">
                        <a href="<?php echo e(url('/home')); ?>"><img src="<?php echo e(asset('logo.png')); ?>" alt="" /></a>
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="shop-menu pull-right">
                        <ul class="nav navbar-nav collapse navbar-collapse">
                            <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                            <li id="dropdown2"><a href="<?php echo e(url('#')); ?>">S h o e s&nbsp;&nbsp;G a l l e r y</a>
                                <div id="dropdowncontent2">
                                    <a href="<?php echo e(url('/sneakersgalery')); ?>">Nike</a>
                                    <a href="<?php echo e(url('/bootsgalery')); ?>">Adidas</a>
                                </div>
                            </li>
                            <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
                            <?php if(!Auth::check()): ?>
                                <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                                <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                            <?php else: ?>
                                <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<br>
<div class="pemesanan">
    <?php if($stock): ?>
    <img src="/shoes gallery/<?php echo e($shoe->img); ?>" alt="" style="width: 800px"> <br>
    size : <?php echo e($shoe->size); ?><br>
    total harga : <?php echo e($shoe->harga * $qty); ?><br>
    Transfer ke 123456 <br>
    <?php else: ?>
    <h1> Maaf Stock tidak cukup</h1>
    <?php endif; ?>
<a href="<?php echo e(url('/')); ?>"><button>Back</button></a>
</div>

<div class="footer5">
    Copyright Reserve (c)2017 , IT Team <br>
    Binus University
</div>
</html>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>