<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shoe extends Model
{
    //
    public $timestamps = False;
}
